<?php
include "includes/navbar.php";

if(isset($_SESSION['username']))
{
$sql="select * from site where id=1";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
  $row=mysqli_fetch_assoc($res);
?>
<div class="main">
<form action="site_setting_check.php?id=1" method="POST" enctype="multipart/form-data">
<div class="card-panel">
<?php
if(isset($_SESSION['message']))
{
echo $_SESSION['message'];
unset($_SESSION['message']);
}
?>
<h5>Site Name</h5>
<input name="name" class="materialize-textarea" placeholder="Site Name..." value="<?php echo $row['site_name'];?>">
<h5>Site Titile</h5>
<input name="title" class="materialize-textarea" placeholder="Site Name." value="<?php
echo $row['site_title'];?>">
<h5>Site Description</h5>
<input name="description" class="materialize-textarea" placeholder="Site Description." value="
<?php echo $row['site_description'];?>">
<h5>Site Footer</h5>
<input name="footer" class="materialize-textarea" placeholder="Site Footer." value="<?php echo $row['site_footer'];?>">
<br>
<div class="center">
<input type="submit" value="Update" name="publish" class="btn blue white-text"> 
</div>

</div>
</form>


</div>
    

    <script type="text/javascript" src="../js/ckeditor/ckeditor.js"></script>
    <?php

    include "includes/footer.php";
    ?>


<?php
}
else
{
  header("Location: dashboard.php");
}
}
?>