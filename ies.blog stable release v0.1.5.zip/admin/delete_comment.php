<?php
include "includes/header.php";
if(isset($_GET['id']))
{
$id=$_GET['id'];
$id=mysqli_real_escape_string($conn,$id);
$id=htmlentities($id);
$sql="delete from comments where id=$id";
$res=mysqli_query($conn,$sql);
if($res)
{
  echo "<div class='center green-text'>Deleted Successfully</div>";
}
else
{
  echo "<div class='center red-text'>Something Went Wrong</div>";
}
}
?>