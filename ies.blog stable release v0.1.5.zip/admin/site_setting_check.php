<?php
include "includes/header.php";
if(isset($_POST['publish']))
{ $id=$_GET['id'];
  $id=mysqli_real_escape_string($conn,$id);
  $id=htmlentities($id);
  $name=$_POST['name'];
  $name=mysqli_real_escape_string($conn,$name);
  $name=htmlentities($name);
  $title=$_POST['title'];
  $title=mysqli_real_escape_string($conn,$title);
  $title=htmlentities($title);
  $data=$_POST['description'];
  $data=mysqli_real_escape_string($conn,$data);
  $data=htmlentities($data);
  $footer=$_POST['footer'];
  $footer=mysqli_real_escape_string($conn,$footer);
$sql="update site set site_title='$name',site_name='$title',site_description='$data',site_footer='$footer' where id=$id";
$res=mysqli_query($conn,$sql);
if($res)
{
$_SESSION['message']="<div class='center green-text'> Site Updated</div>";
header("Location: site_setting.php?id=".$id);
}
else
{
  $_SESSION['message']="<div class='center red-text'> Sorry,Something went wrong.</div>";
  header("Location: site_setting.php?id=".$id);
}
}
?>
