<?php
include "includes/header.php";
if(!isset($_SESSION['username']))
{
?>
<!DOCTYPE html>
<html>
<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/custom.css" />
  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login Page</title>
</head>
<body>  <div class="center">
<div class="row">
<div class="col l4 offset-l3 m6 offset-m2 s12" id="login" >
<div class="card-panel center transparent" style="margin-top:1px">
<h5>Admin Login</h5>
<?php
if(isset($_SESSION['message']))
{
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
?>
<form action="login_check.php" method="POST">
<div class="input-field">
<input type="text" id="username" name="username" placeholder="Username">
</div>
<div class="input-field">
<input type="password" name="password" placeholder="Password">
</div>
<input type="submit" name="login" value="Login" class="btn blue">
</form>
</div>
</div>
</div>
</div>

<?php
include "includes/footer.php";
}
else
{
   header("Location: dashboard.php");
}
?>