<?php
include "includes/header.php";
if(isset($_POST['publish']))
{ $id=$_GET['id'];
  $id=mysqli_real_escape_string($conn,$id);
  $id=htmlentities($id);
  $m1=$_POST['m1'];
  $m1=mysqli_real_escape_string($conn,$m1);
  $m1=htmlentities($m1);
  $l1=$_POST['l1'];
  $l1=mysqli_real_escape_string($conn,$l1);
  $l1=htmlentities($l1);
  $m2=$_POST['m2'];
  $m2=mysqli_real_escape_string($conn,$name);
  $m2=htmlentities($name);
  $l2=$_POST['l2'];
  $l2=mysqli_real_escape_string($conn,$l2);
  $l2=htmlentities($l2);
  $m3=$_POST['m3'];
  $m3=mysqli_real_escape_string($conn,$m3);
  $m3=htmlentities($m3);
  $l3=$_POST['l3'];
  $l3=mysqli_real_escape_string($conn,$l3);
  $l3=htmlentities($l3);
  $m4=$_POST['m4'];
  $m4=mysqli_real_escape_string($conn,$m4);
  $m4=htmlentities($m4);
  $l4=$_POST['l4'];
  $l4=mysqli_real_escape_string($conn,$l4);
  $l4=htmlentities($l4);
$sql="update menus set m1='$m1',l1='$l1',m2='$m2',l2='$l2',m3='$m3',l3='$l3',m4='$m4',l4='$l4' where id=1";
$res=mysqli_query($conn,$sql);
if($res)
{
$_SESSION['message']="<div class='center green-text'>Menus Updated</div>";
header("Location: menu.php?id=".$id);
}
else
{
  $_SESSION['message']="<div class='center red-text'>Sorry,Something went wrong.</div>";
  header("Location: menu.php?id=".$id);
}
}
?>
