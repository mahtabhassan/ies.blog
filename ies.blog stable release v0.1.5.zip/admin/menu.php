<?php
include "includes/navbar.php";
?>
<?php
$sql3="select * from menus where id=1";
$res3=mysqli_query($conn,$sql3);
if(mysqli_num_rows($res3))
{
$row3=mysqli_fetch_assoc($res3);
?>
<<div class="main">
<form action="menu_edit.php?id=1" method="POST" enctype="multipart/form-data">
<div class="card-panel">
<?php
if(isset($_SESSION['message']))
{
echo $_SESSION['message'];
unset($_SESSION['message']);
}
?>
<h5>Edit Menu Item</h5>
<input name="m1" class="materialize-textarea" placeholder="1st Menu Item" value="<?php echo $row3['m1'];?>">
<input name="l1" class="materialize-textarea" placeholder="Link" value="<?php echo $row3['l1'];?>">
<input name="m2" class="materialize-textarea" placeholder="2nd Menu Item" value="<?php
echo $row3['m2'];
?>">
<input name="l2" class="materialize-textarea" placeholder="Link" value="<?php echo $row3['l2'];?>">
<input name="m3" class="materialize-textarea" placeholder="3rd Menu Item" value="<?php echo $row3['m3'];?>">
<input name="l3" class="materialize-textarea" placeholder="Link" value="<?php echo $row3['l3'];?>">
<input name="m4" class="materialize-textarea" placeholder="4th Menu Item" value="<?php echo $row3['m4'];?>">
<input name="l4" class="materialize-textarea" placeholder="Link" value="<?php echo $row3['l4'];?>">
<br>
<div class="center">
<input type="submit" value="Update" name="publish" class="btn blue white-text"> 
</div>

</div>
</form>


</div>
<?php
}
?>
<?php
include "includes/footer.php";
?>