<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'mahtab2003');
define('DB_NAME', 'cms');
?>