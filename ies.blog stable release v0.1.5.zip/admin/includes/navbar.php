<?php
include "includes/header.php";
if(isset($_SESSION['username']))
{
?>
<!DOCTYPE html>
<html>
<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/custom.css" />
<style>
footer,header,.main{
padding-left:300px;
}
@media(max-width:992px)
{
  footer,header,.main{
padding-left:0px;
}
}
</style>
  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $row2['site_title'];?> - <?php echo $row2['site_description'];?></title>
</head>
<body>
<nav class="blue">
<div class="nav-wrapper">
<div class="container">
<a href="" class="brand-logo center white-text"><?php echo $row2['site_name'];?></a>
<a href="" class="button-collapse white-text show-on-large" data-activates="sidenav"><i class="material-icons">menu</i></a>
</div>
</div>
</nav>
<ul class="side-nav fixed" id="sidenav">
<li>
<div class="user-view">
<div class="background">
<img src="../img/system/blue.png" alt="" class="blue responsive-img">
</div>
<a href=""><img src="../img/system/user.png" alt="" class="circle"></a>
<span class="name white-text"><?php echo $_SESSION['username'];?></span>
<span class="email white-text">
<?php
$user=$_SESSION['username'];
$sql="select email from users where username='$user'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
echo $row['email'];
?>
</span>
</div>
</li>
<li>
<a href="dashboard.php">Dashboard</a>
</li>
<li>
<a href="post.php">Posts</a>
</li>
<li>
<a href="statics.php">Statics</a>
</li>
<li>
<a href="image.php">Images</a>
</li>
<li>
<a href="menu.php">Menu</a>
</li>
<li>
<a href="comments.php">Comments</a>
</li>
<li>
<a href="setting.php">User Settings</a>
</li>
<li>
<a href="site_setting.php">Site Setting</a>
</li>
<div class="divider">

</div>
<li><a href="logout.php">Logout</a></li>
</ul>
<?php
}
else
{
  $_SESSION['message']="<div class='center red-text'>Login To Continue</div>";
  header("Location: login.php");
}
?>