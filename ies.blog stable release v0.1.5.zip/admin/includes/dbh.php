<?php
include "config.php";
$dbservername=DB_HOST;
$dbuser=DB_USER;
$dbpass=DB_PASS;
$dbname=DB_NAME;
$conn=mysqli_connect($dbservername,$dbuser,$dbpass,$dbname);
$sql9="select * from site where id=1";
$res2=mysqli_query($conn,$sql9);
$row2=mysqli_fetch_assoc($res2);
?>