<?php
include "includes/navbar.php";
if (isset($_SESSION['username'])) {
?>
<div class="main">
<div class="row">
<div class="col l12 m12 s12">
<ul class="collection with-header">
<li class="collection-header blue">
<h5 class="white-text">Post Views</h5>
</li>
<?php
  $sql="select * from posts";
  $res=mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)>0)
  {
  while($row=mysqli_fetch_assoc($res)){
?>
<li class="collection-item">
<a href="../post.php?id=<?php echo $row['id']?>"><?php echo $row['id']?>. <?php echo $row['title']?><div class="riht"><i class="fa fa-eye blue-text tiny"></i> Views <?php echo $row['view']; ?></div></a>
</li>
<?php
 }
}
else{
  echo "<div class='center red-text'>Nothing to Show.</div>";
}
}
?>
</ul>
</div>
</div>
</div>
<?php
include 'includes/footer.php';