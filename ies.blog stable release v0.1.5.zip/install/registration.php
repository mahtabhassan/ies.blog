<?php
include "../admin/includes/header.php";
if(!isset($_SESSION['username']))
{
?>
<!DOCTYPE html>
<html>
<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/custom.css" />
  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Signup Page</title>
</head>
<body>
<?php
if(isset($_SESSION['message']))
{
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
?>
<div class="row">
<div class="col l6 offset-l3 m8 offset-m2 s12" id="signup">
<div class="card-panel center transparent" style="margin-top:1px">
<h5>SignUp Now</h5>
<form action="admin_register.php" method="POST">
<div class="input-field">
<input type="email" name="email" id="email" placeholder="Enter Email" class="validate"> 
<label for="email" data-error="Invalid Email Format" data-success="Valid Email"></label>
</div>
<div class="input-field">
<input type="text" id="username" name="username" placeholder="Username">
</div>
<div class="input-field">
<input type="password" name="password" placeholder="Password">
</div>
<input type="submit" name="signup" class="btn blue" value="Sign Up">
</form>
</div>
</div>
</div>
<?php
include "../admin/includes/footer.php";
}
else
{
   header("Location: dashboard.php");
}
?>