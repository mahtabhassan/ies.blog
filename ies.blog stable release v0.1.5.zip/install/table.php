<?php
include "header.php";
include "../includes/config.php";
$dbhost=DB_HOST;
$dbuser=DB_USER;
$dbpass=DB_PASS;
$dbname=DB_NAME;
$conn=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
// sql to create table
$sql = "CREATE TABLE users( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, username VARCHAR(30) NOT NULL, email VARCHAR(30) NOT NULL, password VARCHAR(70) NOT NULL UNIQUE )";
if(mysqli_query($conn, $sql)){
$sql1 = "CREATE TABLE posts( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, title VARCHAR(30) NOT NULL, content VARCHAR(30) NOT NULL, feature_img TEXT(70) NOT NULL,view VARCHAR(30) NOT NULL )";
if(mysqli_query($conn, $sql1)){
$sql2 = "CREATE TABLE comments( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, post_id VARCHAR(30) NOT NULL, email VARCHAR(30) NOT NULL, comment_text VARCHAR(30) NOT NULL )";
if(mysqli_query($conn, $sql2)){
	$sql3 = "CREATE TABLE menus( id INT NOT NULL PRIMARY KEY, m1 VARCHAR(30) NOT NULL, l1 VARCHAR(30) NOT NULL,m2 VARCHAR(30) NOT NULL, l2 VARCHAR(30) NOT NULL,m3 VARCHAR(30) NOT NULL, l3 VARCHAR(30) NOT NULL,m4 VARCHAR(30) NOT NULL, l4 VARCHAR(30) NOT NULL )";
if(mysqli_query($conn, $sql3)){
	$sql4 = "CREATE TABLE site( id INT NOT NULL PRIMARY KEY, site_name VARCHAR(30) NOT NULL, site_title VARCHAR(30) NOT NULL, site_description VARCHAR(30) NOT NULL, site_footer VARCHAR(30) NOT NULL )";
if(mysqli_query($conn, $sql4)){
	$sql5 = "INSERT INTO menus(id) VALUES (1)";
if(mysqli_query($conn, $sql5)){
	$sql6 = "INSERT INTO site(id) VALUES (1)";
if(mysqli_query($conn, $sql6)){
  header("Location: registration.php");
}
}
}
}
}
}
}
else{
echo"<div class='card-panel center red-text'>Oops!<br>Something Wents Wrong.Re-try Later</div>";
}

?>