<?php
include "header.php"
?>
<div class="container center;">
<div class="col l6 m8 s12">
<div class="card-panel red center transparent">
<div class="red-text">
<form action="insert.php" method="POST">
<input type="text" name="DB_HOST" placeholder="Enter Host"><br>
<input type="text" name="DB_USER" placeholder="Enter Username"><br>
<input type="text" name="DB_PASS" placeholder="Enter Password"><br>
<input type="text" name="DB_NAME" placeholder="Enter DB Name"><br>
<input type="submit" class="btn btn-round red" Value="Install">
</form>
</div>
</div>
</div>
</div>