<?php
include "header.php"
?>
<div class="container center">
<div class="col l6 m8 s12">
<div class="card-panel red center transparent">
<div class="green-text">
<h4 class="center green-text">Create Tables Automatically in Database by Click Down Button</h4>
<form action="table.php">
<input type="submit" class="btn green" value="Create Tables">
</form>
</div>
</div>
</div>
</div>