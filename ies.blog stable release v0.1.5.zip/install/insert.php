<?php
$fh = fopen('../includes/config.php', 'w');
fwrite($fh, chr(60) . "?php\n");
fwrite($fh, sprintf("define('DB_HOST', '%s');\n", addslashes($_POST['DB_HOST'])));
fwrite($fh, sprintf("define('DB_USER', '%s');\n", addslashes($_POST['DB_USER'])));
fwrite($fh, sprintf("define('DB_PASS', '%s');\n", addslashes($_POST['DB_PASS'])));
fwrite($fh, sprintf("define('DB_NAME', '%s');\n", addslashes($_POST['DB_NAME'])));
fwrite($fh, sprintf('?>'));
fclose($fh);

$fh = fopen('../admin/includes/config.php', 'w');
fwrite($fh, chr(60) . "?php\n");
fwrite($fh, sprintf("define('DB_HOST', '%s');\n", addslashes($_POST['DB_HOST'])));
fwrite($fh, sprintf("define('DB_USER', '%s');\n", addslashes($_POST['DB_USER'])));
fwrite($fh, sprintf("define('DB_PASS', '%s');\n", addslashes($_POST['DB_PASS'])));
fwrite($fh, sprintf("define('DB_NAME', '%s');\n", addslashes($_POST['DB_NAME'])));
fwrite($fh, sprintf('?>'));
fclose($fh);
header("Location: create_table.php");
?>