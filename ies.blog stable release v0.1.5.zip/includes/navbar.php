<div class="navbar-fixed blue">
<nav class="blue">
<div class="nav-wrapper">
<div class="container">
<a href="index.php" class="brand-logo center white-text"><?php echo $row2['site_name'];?></a>
<a href="" class="button-collapse white-text" data-activates="sidenav"><i class="material-icons">menu</i></a>
<ul class="hide-on-small-and-down right">
<?php
$sql="select * from menus where id=1";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
?>
<li><a class="white-text" href="<?php echo $row['l1'];?>"><?php echo $row['m1'];?></a></li>
<li><a class="white-text" href="<?php echo $row['l2'];?>"><?php echo $row['m2'];?></a></li>
<li><a class="white-text" href="<?php echo $row['l3'];?>"><?php echo $row['m3'];?></a></li>
<li><a class="white-text" href="<?php echo $row['l4'];?>"><?php echo $row['m4'];?></a></li>
</ul>
</div>
</div>
</nav>
</div>
<ul id="sidenav" class="side-nav">
<li><a class="white-text" href="<?php echo $row['l1'];?>"><?php echo $row['m1'];?></a></li>
<div class="divider"></div>
<li><a class="white-text" href="<?php echo $row['l2'];?>"><?php echo $row['m2'];?></a></li>
<div class="divider"></div>
<li><a class="white-text" href="<?php echo $row['l3'];?>"><?php echo $row['m3'];?></a></li>
<div class="divider"></div>
<li><a class="white-text" href="<?php echo $row['l4'];?>"><?php echo $row['m4'];?></a></li>
</ul>