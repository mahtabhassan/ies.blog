<footer class="page-footer blue">
<div class="container">
IES.Blog By Mahtab Hassan
<span class="right">
Follow Us On
<a href="" class="btn btn-floating white"><i class="fa fa-facebook blue-text" aria-hidden="true"></i></a>

<a href="" class="btn btn-floating white"><i class="fa fa-instagram red"></i></a>
<a href="" class="btn btn-floating white"><i class="fa fa-twitter blue-text"></i></a>
<a href="" class="btn btn-floating white"><i class="fa fa-youtube red" aria-hidden="true"></i></a>
</span> 
</div>
<div class="clearfix"></div>

<div class="footer-copyright">
<div class="container center">
<p class="gray"><?php echo $row2['site_footer'];?> <?php echo $row2['site_title'];?></p>
</div>
</div>
</footer>
<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script>
    $(document).ready(function () {
      // Custom JS & jQuery here
      $('.button-collapse').sideNav();
    });
  </script>
</body>

</html>