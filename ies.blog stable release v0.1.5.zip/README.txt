<-----------Features--------->

There are many Features in our CMS
*Add Post
*Edit Post
*Delete Post
*Modify Site Setting
*update user setting
*can modify by custom.css
*comment system
*can change menu links
*one admin at a time
*License Public MTG2

<------------Note------------>

You need to install the script first to use this CMS

<------------Install---------->

To install on local host just
1. copy and paste the .zip file in htdocs folder(C:/xampp/htdocs/).
2. Extract the .zip file.
3. Open Web Browser and in seaech bar type (https://localhost/ies.blog).
4. Follow steps and complete setup.
5. Rename or Delete install folder in ies.blog folder in htdocs folder.
5. Login to admin panel and Enjoy.

To install on a server
1. upload the .zip file in public_htnl folder.
2. Extract the .zip file.
3. Open Web Browser and in seaech bar type go to your site (https://example.com/ies.blog).
4. Follow steps and complete setup.
5. Rename or Delete install folder in ies.blog folder in public_html folder.
5. Login to admin panel and Enjoy.

<----------For Developers----------->

We have used Materialize CSS but you can add your own CSS in custom.css in css folder.

<----------Security------------->

This CMS is secured from SQL Injections and Snippers The data survey security is insured by IES Team

<----------Copyrights----------->

All copyrights are reserved by the IES Team.

<------------Donate------------->

Bitcoin Wallet address: 
3JHhLZ5rcDTWyudQfLCZaEMPDg5TtmmDbR

Bitcoin Cash wallet address:
qplewlsgr2erys67kk2fxen9hv4z2lt93cqq5sza7h

Ethereum wallet address:
0x7B90E49e204aE452DdFEa3d82379D6D4A54D0003

Litecoin Wallet Address:
MQAMLLv4ujYjXR4i2i2ZxevJCqfo1ifHg3

Waves Wallet
3PCUuRSQsMvoLc92vGDaiqQixyQU6vamyyH

Tron Wallet Address
TYBpfA2b3ZpNc5cwUGybKRcDcRFQNzZYrp

Payeer Account
P1034396974
